# Madonna Bot 💋🎤

Um bot do Telegram com personalidade debochada e romântica, usando ChatGPT.  
Roda 24h por dia gratuitamente via [Render.com](https://render.com).

### 🌟 Comandos:
- `/beijo` – Manda um beijo especial
- `/conselho` – Dá conselhos amorosos ou debochados
- `/verso` – Solta uma frase dramática, romântica ou poética

---

### 🚀 Como usar:
1. Suba esses arquivos em um repositório no GitHub.
2. Vá em [render.com](https://render.com) e conecte sua conta GitHub.
3. Crie um novo **Web Service** e selecione esse repositório.
4. O Render detectará o arquivo `render.yaml`.
5. Adicione as variáveis de ambiente:
   - `TELEGRAM_TOKEN` → pegue com o BotFather
   - `OPENAI_API_KEY` → pegue em https://platform.openai.com/api-keys
6. Clique em **Deploy** e pronto! Madonna estará online 24h.

💅 Feito com amor, drama e deboche.
